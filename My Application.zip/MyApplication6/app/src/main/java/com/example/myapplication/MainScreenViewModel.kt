package com.example.myapplication

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class MainScreenViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(MainScreenState())
    val uiState: StateFlow<MainScreenState> = _uiState.asStateFlow()
    val encryptor = MsgCipherDecipher()
   fun encryptDecryptText(text: String){
        _uiState.update{ currentState ->
            currentState.copy(
                enteredText = text,
                outputText = encryptor.returnFinalMessage(text),

            )
        }
    }

    fun updateEnteredText(text: String){
        _uiState.update{ currentState ->
            currentState.copy(
                enteredText = text,
                outputText = currentState.outputText,
                )
                        }
    }
}

data class MainScreenState(
    val enteredText: String? = null,
    val outputText: String? = null
)