package com.example.myapplication;

import android.content.Intent;
import android.os.Build;

import java.util.Base64;

public class CipherDecipherExample {


	public static void main(String[] args)  {

		}
	}

